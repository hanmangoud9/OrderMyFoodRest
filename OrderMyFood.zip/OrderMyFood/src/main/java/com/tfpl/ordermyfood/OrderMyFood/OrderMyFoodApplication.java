package com.tfpl.ordermyfood.OrderMyFood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderMyFoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderMyFoodApplication.class, args);
	}

}
