package com.tfpl.ordermyfood.OrderMyFood;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderMyFoodApplicationTests {

	@Test
	void contextLoads() {
	}

}
